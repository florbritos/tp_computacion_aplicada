help() {
    echo "Script para hacer backup de un directorio."
    echo
    echo "Opciones:"
    echo "  -help   Guía del usuario para el uso del script."
    echo
    echo "Guía del comando"
    echo "  1) Nombre del script - 2) Nombre del directorio origen que se quiere hacer un backup - 3) Nombre del directorio destino donde se quiere guardar el archivo backup"
    echo
    echo "Ejemplo:"
    echo "  /opt/scripts/backup_full.sh /var/log /backup_dir"
}

if [ "$1" == "-help" ]; then
    help
    exit 0
fi

ORIGEN=$1
DESTINO=$2

if [ -z "$ORIGEN" ]; then
    echo "Error: No se ingresó la ruta de origen."
    exit 1
fi

if [ -z "$DESTINO" ]; then
    echo "Error: No se ingresó la ruta de destino."
    exit 1
fi

if [ ! -d "$ORIGEN" ]; then
    echo "Error: La ruta de origen '$ORIGEN' no existe o no es un directorio."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: La ruta de destino '$DESTINO' no existe o no es un directorio."
    exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")
ARCHIVO_BACKUP="${DESTINO}/${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO_BACKUP" -C "$(dirname "$ORIGEN")" "$NOMBRE_DIR"

echo "Backup hecho exitosamente en: $ARCHIVO_BACKUP"
